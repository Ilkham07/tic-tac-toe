package kz.danekerscode.ttt.api.model.dto

data class MoveRequest(
    val x: Int,
    val y: Int
)