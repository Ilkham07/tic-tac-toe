package kz.danekerscode.ttt.api.model.enums

enum class GameRequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
}