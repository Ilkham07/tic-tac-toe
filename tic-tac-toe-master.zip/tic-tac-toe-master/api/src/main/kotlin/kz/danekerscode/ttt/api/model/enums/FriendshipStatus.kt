package kz.danekerscode.ttt.api.model.enums

enum class FriendshipStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    NONE
}
