package kz.danekerscode.ttt.api.model.enums

enum class GameRoomStatus {
    WAITING, IN_PROGRESS, FINISHED
}